package org.vaadin.activiti.simpletravel.ui.dashboard;

import com.github.peholmst.mvp4vaadin.View;
import com.github.peholmst.mvp4vaadin.ViewEvent;

public class UserLoggedOutEvent extends ViewEvent {

    public UserLoggedOutEvent(View source) {
        super(source);
    }
}
