package org.vaadin.activiti.simpletravel.identity;

public interface Groups {
        
    String GROUP_EMPLOYEES = "employees";
    String GROUP_SECRETARIES = "secretary";
    String GROUP_MANAGERS = "management";
    String GROUP_PAYROLLADMINS = "cashier";
}
