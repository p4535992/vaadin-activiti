package org.vaadin.activiti.simpletravel.ui.forms;

import com.github.peholmst.mvp4vaadin.View;
import com.github.peholmst.mvp4vaadin.ViewEvent;

public class FormClosedEvent extends ViewEvent {

    public FormClosedEvent(View source) {
        super(source);
    }
    
}
