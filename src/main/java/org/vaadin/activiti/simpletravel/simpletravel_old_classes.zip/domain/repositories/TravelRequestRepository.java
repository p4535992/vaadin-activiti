package org.vaadin.activiti.simpletravel.domain.repositories;

import org.vaadin.activiti.simpletravel.domain.TravelRequest;

public interface TravelRequestRepository extends Repository<TravelRequest> {
    
}
