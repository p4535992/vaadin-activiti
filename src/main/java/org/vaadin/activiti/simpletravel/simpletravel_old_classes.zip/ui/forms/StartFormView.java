package org.vaadin.activiti.simpletravel.ui.forms;

import org.activiti.engine.form.StartFormData;

public interface StartFormView extends FormView {
        
    void setStartFormData(StartFormData startFormData);
}
