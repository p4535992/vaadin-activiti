package org.vaadin.activiti.simpletravel.domain;

public enum Decision {

    APPROVED, DENIED
    
}
